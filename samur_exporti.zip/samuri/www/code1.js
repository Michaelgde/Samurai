gdjs.MenuCode = {};
gdjs.MenuCode.localVariables = [];
gdjs.MenuCode.GDtittleObjects1= [];
gdjs.MenuCode.GDtittleObjects2= [];
gdjs.MenuCode.GDtittle2Objects1= [];
gdjs.MenuCode.GDtittle2Objects2= [];
gdjs.MenuCode.GDplayObjects1= [];
gdjs.MenuCode.GDplayObjects2= [];
gdjs.MenuCode.GDoptionsObjects1= [];
gdjs.MenuCode.GDoptionsObjects2= [];
gdjs.MenuCode.GDquitObjects1= [];
gdjs.MenuCode.GDquitObjects2= [];
gdjs.MenuCode.GDNewSpriteObjects1= [];
gdjs.MenuCode.GDNewSpriteObjects2= [];
gdjs.MenuCode.GDPlayerObjects1= [];
gdjs.MenuCode.GDPlayerObjects2= [];


gdjs.MenuCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11563028);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "Pop sound effect edited.MP3", false, runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber(), 1);
}}

}


};gdjs.MenuCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11568388);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "Pop sound effect edited.MP3", false, runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber(), 1);
}}

}


};gdjs.MenuCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11575172);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "Pop sound effect edited.MP3", false, runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber(), 1);
}}

}


};gdjs.MenuCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.adMob.setTestMode(true);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("play"), gdjs.MenuCode.GDplayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MenuCode.GDplayObjects1.length;i<l;++i) {
    if ( gdjs.MenuCode.GDplayObjects1[i].getBehavior("ButtonFSM").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MenuCode.GDplayObjects1[k] = gdjs.MenuCode.GDplayObjects1[i];
        ++k;
    }
}
gdjs.MenuCode.GDplayObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Untitled scene", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("play"), gdjs.MenuCode.GDplayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MenuCode.GDplayObjects1.length;i<l;++i) {
    if ( gdjs.MenuCode.GDplayObjects1[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MenuCode.GDplayObjects1[k] = gdjs.MenuCode.GDplayObjects1[i];
        ++k;
    }
}
gdjs.MenuCode.GDplayObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MenuCode.GDplayObjects1 */
{for(var i = 0, len = gdjs.MenuCode.GDplayObjects1.length ;i < len;++i) {
    gdjs.MenuCode.GDplayObjects1[i].getBehavior("Effect").enableEffect("thickness", true);
}
}{for(var i = 0, len = gdjs.MenuCode.GDplayObjects1.length ;i < len;++i) {
    gdjs.MenuCode.GDplayObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.6, 4, 4, 4, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.MenuCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("play"), gdjs.MenuCode.GDplayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MenuCode.GDplayObjects1.length;i<l;++i) {
    if ( !(gdjs.MenuCode.GDplayObjects1[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.MenuCode.GDplayObjects1[k] = gdjs.MenuCode.GDplayObjects1[i];
        ++k;
    }
}
gdjs.MenuCode.GDplayObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MenuCode.GDplayObjects1 */
{for(var i = 0, len = gdjs.MenuCode.GDplayObjects1.length ;i < len;++i) {
    gdjs.MenuCode.GDplayObjects1[i].getBehavior("Effect").enableEffect("thickness", false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("quit"), gdjs.MenuCode.GDquitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MenuCode.GDquitObjects1.length;i<l;++i) {
    if ( gdjs.MenuCode.GDquitObjects1[i].getBehavior("ButtonFSM").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MenuCode.GDquitObjects1[k] = gdjs.MenuCode.GDquitObjects1[i];
        ++k;
    }
}
gdjs.MenuCode.GDquitObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("quit"), gdjs.MenuCode.GDquitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MenuCode.GDquitObjects1.length;i<l;++i) {
    if ( gdjs.MenuCode.GDquitObjects1[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MenuCode.GDquitObjects1[k] = gdjs.MenuCode.GDquitObjects1[i];
        ++k;
    }
}
gdjs.MenuCode.GDquitObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MenuCode.GDquitObjects1 */
{for(var i = 0, len = gdjs.MenuCode.GDquitObjects1.length ;i < len;++i) {
    gdjs.MenuCode.GDquitObjects1[i].getBehavior("Effect").enableEffect("thickness", true);
}
}{for(var i = 0, len = gdjs.MenuCode.GDquitObjects1.length ;i < len;++i) {
    gdjs.MenuCode.GDquitObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.6, 4, 4, 4, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.MenuCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("quit"), gdjs.MenuCode.GDquitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MenuCode.GDquitObjects1.length;i<l;++i) {
    if ( !(gdjs.MenuCode.GDquitObjects1[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.MenuCode.GDquitObjects1[k] = gdjs.MenuCode.GDquitObjects1[i];
        ++k;
    }
}
gdjs.MenuCode.GDquitObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MenuCode.GDquitObjects1 */
{for(var i = 0, len = gdjs.MenuCode.GDquitObjects1.length ;i < len;++i) {
    gdjs.MenuCode.GDquitObjects1[i].getBehavior("Effect").enableEffect("thickness", false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("options"), gdjs.MenuCode.GDoptionsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MenuCode.GDoptionsObjects1.length;i<l;++i) {
    if ( gdjs.MenuCode.GDoptionsObjects1[i].getBehavior("ButtonFSM").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MenuCode.GDoptionsObjects1[k] = gdjs.MenuCode.GDoptionsObjects1[i];
        ++k;
    }
}
gdjs.MenuCode.GDoptionsObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "Pop sound effect edited.MP3", false, runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber(), 1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Options", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("options"), gdjs.MenuCode.GDoptionsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MenuCode.GDoptionsObjects1.length;i<l;++i) {
    if ( gdjs.MenuCode.GDoptionsObjects1[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MenuCode.GDoptionsObjects1[k] = gdjs.MenuCode.GDoptionsObjects1[i];
        ++k;
    }
}
gdjs.MenuCode.GDoptionsObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MenuCode.GDoptionsObjects1 */
{for(var i = 0, len = gdjs.MenuCode.GDoptionsObjects1.length ;i < len;++i) {
    gdjs.MenuCode.GDoptionsObjects1[i].getBehavior("Effect").enableEffect("thickness", true);
}
}{for(var i = 0, len = gdjs.MenuCode.GDoptionsObjects1.length ;i < len;++i) {
    gdjs.MenuCode.GDoptionsObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.6, 4, 4, 4, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.MenuCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("options"), gdjs.MenuCode.GDoptionsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MenuCode.GDoptionsObjects1.length;i<l;++i) {
    if ( !(gdjs.MenuCode.GDoptionsObjects1[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.MenuCode.GDoptionsObjects1[k] = gdjs.MenuCode.GDoptionsObjects1[i];
        ++k;
    }
}
gdjs.MenuCode.GDoptionsObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MenuCode.GDoptionsObjects1 */
{for(var i = 0, len = gdjs.MenuCode.GDoptionsObjects1.length ;i < len;++i) {
    gdjs.MenuCode.GDoptionsObjects1[i].getBehavior("Effect").enableEffect("thickness", false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.adMob.isBannerLoaded());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(25723180);
}
}
if (isConditionTrue_0) {
{gdjs.adMob.setupBanner("ca-app-pub-3940256099942544", "ca-app-pub-3940256099942544", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.adMob.isBannerLoaded();
if (isConditionTrue_0) {
{gdjs.adMob.showBanner();
}}

}


};

gdjs.MenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MenuCode.GDtittleObjects1.length = 0;
gdjs.MenuCode.GDtittleObjects2.length = 0;
gdjs.MenuCode.GDtittle2Objects1.length = 0;
gdjs.MenuCode.GDtittle2Objects2.length = 0;
gdjs.MenuCode.GDplayObjects1.length = 0;
gdjs.MenuCode.GDplayObjects2.length = 0;
gdjs.MenuCode.GDoptionsObjects1.length = 0;
gdjs.MenuCode.GDoptionsObjects2.length = 0;
gdjs.MenuCode.GDquitObjects1.length = 0;
gdjs.MenuCode.GDquitObjects2.length = 0;
gdjs.MenuCode.GDNewSpriteObjects1.length = 0;
gdjs.MenuCode.GDNewSpriteObjects2.length = 0;
gdjs.MenuCode.GDPlayerObjects1.length = 0;
gdjs.MenuCode.GDPlayerObjects2.length = 0;

gdjs.MenuCode.eventsList3(runtimeScene);

return;

}

gdjs['MenuCode'] = gdjs.MenuCode;
