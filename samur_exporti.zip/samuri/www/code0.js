gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.localVariables = [];
gdjs.Untitled_32sceneCode.GDKatanaObjects2_1final = [];

gdjs.Untitled_32sceneCode.GDWoodLeftObjects2_1final = [];

gdjs.Untitled_32sceneCode.GDWoodObjects2_1final = [];

gdjs.Untitled_32sceneCode.GDWoodRightObjects2_1final = [];

gdjs.Untitled_32sceneCode.GDleftObjects1_1final = [];

gdjs.Untitled_32sceneCode.GDrightObjects2_1final = [];

gdjs.Untitled_32sceneCode.GDWoodObjects1= [];
gdjs.Untitled_32sceneCode.GDWoodObjects2= [];
gdjs.Untitled_32sceneCode.GDWoodObjects3= [];
gdjs.Untitled_32sceneCode.GDWoodObjects4= [];
gdjs.Untitled_32sceneCode.GDGroundObjects1= [];
gdjs.Untitled_32sceneCode.GDGroundObjects2= [];
gdjs.Untitled_32sceneCode.GDGroundObjects3= [];
gdjs.Untitled_32sceneCode.GDGroundObjects4= [];
gdjs.Untitled_32sceneCode.GDKatanaObjects1= [];
gdjs.Untitled_32sceneCode.GDKatanaObjects2= [];
gdjs.Untitled_32sceneCode.GDKatanaObjects3= [];
gdjs.Untitled_32sceneCode.GDKatanaObjects4= [];
gdjs.Untitled_32sceneCode.GDRootObjects1= [];
gdjs.Untitled_32sceneCode.GDRootObjects2= [];
gdjs.Untitled_32sceneCode.GDRootObjects3= [];
gdjs.Untitled_32sceneCode.GDRootObjects4= [];
gdjs.Untitled_32sceneCode.GDWoodLeftObjects1= [];
gdjs.Untitled_32sceneCode.GDWoodLeftObjects2= [];
gdjs.Untitled_32sceneCode.GDWoodLeftObjects3= [];
gdjs.Untitled_32sceneCode.GDWoodLeftObjects4= [];
gdjs.Untitled_32sceneCode.GDWoodRightObjects1= [];
gdjs.Untitled_32sceneCode.GDWoodRightObjects2= [];
gdjs.Untitled_32sceneCode.GDWoodRightObjects3= [];
gdjs.Untitled_32sceneCode.GDWoodRightObjects4= [];
gdjs.Untitled_32sceneCode.GDbgObjects1= [];
gdjs.Untitled_32sceneCode.GDbgObjects2= [];
gdjs.Untitled_32sceneCode.GDbgObjects3= [];
gdjs.Untitled_32sceneCode.GDbgObjects4= [];
gdjs.Untitled_32sceneCode.GDheight_9595limitObjects1= [];
gdjs.Untitled_32sceneCode.GDheight_9595limitObjects2= [];
gdjs.Untitled_32sceneCode.GDheight_9595limitObjects3= [];
gdjs.Untitled_32sceneCode.GDheight_9595limitObjects4= [];
gdjs.Untitled_32sceneCode.GDdebugObjects1= [];
gdjs.Untitled_32sceneCode.GDdebugObjects2= [];
gdjs.Untitled_32sceneCode.GDdebugObjects3= [];
gdjs.Untitled_32sceneCode.GDdebugObjects4= [];
gdjs.Untitled_32sceneCode.GDslice_9595spotObjects1= [];
gdjs.Untitled_32sceneCode.GDslice_9595spotObjects2= [];
gdjs.Untitled_32sceneCode.GDslice_9595spotObjects3= [];
gdjs.Untitled_32sceneCode.GDslice_9595spotObjects4= [];
gdjs.Untitled_32sceneCode.GDpoinObjects1= [];
gdjs.Untitled_32sceneCode.GDpoinObjects2= [];
gdjs.Untitled_32sceneCode.GDpoinObjects3= [];
gdjs.Untitled_32sceneCode.GDpoinObjects4= [];
gdjs.Untitled_32sceneCode.GDpointsObjects1= [];
gdjs.Untitled_32sceneCode.GDpointsObjects2= [];
gdjs.Untitled_32sceneCode.GDpointsObjects3= [];
gdjs.Untitled_32sceneCode.GDpointsObjects4= [];
gdjs.Untitled_32sceneCode.GDtimeObjects1= [];
gdjs.Untitled_32sceneCode.GDtimeObjects2= [];
gdjs.Untitled_32sceneCode.GDtimeObjects3= [];
gdjs.Untitled_32sceneCode.GDtimeObjects4= [];
gdjs.Untitled_32sceneCode.GDNewTextObjects1= [];
gdjs.Untitled_32sceneCode.GDNewTextObjects2= [];
gdjs.Untitled_32sceneCode.GDNewTextObjects3= [];
gdjs.Untitled_32sceneCode.GDNewTextObjects4= [];
gdjs.Untitled_32sceneCode.GDbarObjects1= [];
gdjs.Untitled_32sceneCode.GDbarObjects2= [];
gdjs.Untitled_32sceneCode.GDbarObjects3= [];
gdjs.Untitled_32sceneCode.GDbarObjects4= [];
gdjs.Untitled_32sceneCode.GDscrObjects1= [];
gdjs.Untitled_32sceneCode.GDscrObjects2= [];
gdjs.Untitled_32sceneCode.GDscrObjects3= [];
gdjs.Untitled_32sceneCode.GDscrObjects4= [];
gdjs.Untitled_32sceneCode.GDFailTextObjects1= [];
gdjs.Untitled_32sceneCode.GDFailTextObjects2= [];
gdjs.Untitled_32sceneCode.GDFailTextObjects3= [];
gdjs.Untitled_32sceneCode.GDFailTextObjects4= [];
gdjs.Untitled_32sceneCode.GDrestartObjects1= [];
gdjs.Untitled_32sceneCode.GDrestartObjects2= [];
gdjs.Untitled_32sceneCode.GDrestartObjects3= [];
gdjs.Untitled_32sceneCode.GDrestartObjects4= [];
gdjs.Untitled_32sceneCode.GDhighscoreTextObjects1= [];
gdjs.Untitled_32sceneCode.GDhighscoreTextObjects2= [];
gdjs.Untitled_32sceneCode.GDhighscoreTextObjects3= [];
gdjs.Untitled_32sceneCode.GDhighscoreTextObjects4= [];
gdjs.Untitled_32sceneCode.GDbackObjects1= [];
gdjs.Untitled_32sceneCode.GDbackObjects2= [];
gdjs.Untitled_32sceneCode.GDbackObjects3= [];
gdjs.Untitled_32sceneCode.GDbackObjects4= [];
gdjs.Untitled_32sceneCode.GDHScoreObjects1= [];
gdjs.Untitled_32sceneCode.GDHScoreObjects2= [];
gdjs.Untitled_32sceneCode.GDHScoreObjects3= [];
gdjs.Untitled_32sceneCode.GDHScoreObjects4= [];
gdjs.Untitled_32sceneCode.GDMenuObjects1= [];
gdjs.Untitled_32sceneCode.GDMenuObjects2= [];
gdjs.Untitled_32sceneCode.GDMenuObjects3= [];
gdjs.Untitled_32sceneCode.GDMenuObjects4= [];
gdjs.Untitled_32sceneCode.GDGrayObjects1= [];
gdjs.Untitled_32sceneCode.GDGrayObjects2= [];
gdjs.Untitled_32sceneCode.GDGrayObjects3= [];
gdjs.Untitled_32sceneCode.GDGrayObjects4= [];
gdjs.Untitled_32sceneCode.GDleftObjects1= [];
gdjs.Untitled_32sceneCode.GDleftObjects2= [];
gdjs.Untitled_32sceneCode.GDleftObjects3= [];
gdjs.Untitled_32sceneCode.GDleftObjects4= [];
gdjs.Untitled_32sceneCode.GDrightObjects1= [];
gdjs.Untitled_32sceneCode.GDrightObjects2= [];
gdjs.Untitled_32sceneCode.GDrightObjects3= [];
gdjs.Untitled_32sceneCode.GDrightObjects4= [];
gdjs.Untitled_32sceneCode.GDPlayerObjects1= [];
gdjs.Untitled_32sceneCode.GDPlayerObjects2= [];
gdjs.Untitled_32sceneCode.GDPlayerObjects3= [];
gdjs.Untitled_32sceneCode.GDPlayerObjects4= [];


gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(28033436);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "Pop sound effect edited.MP3", false, runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber(), 1);
}}

}


};gdjs.Untitled_32sceneCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(28036468);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "Pop sound effect edited.MP3", false, runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber(), 1);
}}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDrightObjects3Objects = Hashtable.newFrom({"right": gdjs.Untitled_32sceneCode.GDrightObjects3});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDleftObjects2Objects = Hashtable.newFrom({"left": gdjs.Untitled_32sceneCode.GDleftObjects2});
gdjs.Untitled_32sceneCode.eventsList2 = function(runtimeScene) {

{



}


{

gdjs.Untitled_32sceneCode.GDrightObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Untitled_32sceneCode.GDrightObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("right"), gdjs.Untitled_32sceneCode.GDrightObjects3);
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.input.cursorOnObject(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDrightObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_2) {
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDrightObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDrightObjects2_1final.indexOf(gdjs.Untitled_32sceneCode.GDrightObjects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDrightObjects2_1final.push(gdjs.Untitled_32sceneCode.GDrightObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDrightObjects2_1final, gdjs.Untitled_32sceneCode.GDrightObjects2);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects2[i].setX(700);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects2[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

gdjs.Untitled_32sceneCode.GDleftObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Untitled_32sceneCode.GDleftObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("left"), gdjs.Untitled_32sceneCode.GDleftObjects2);
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.input.cursorOnObject(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDleftObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_2) {
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDleftObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDleftObjects1_1final.indexOf(gdjs.Untitled_32sceneCode.GDleftObjects2[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDleftObjects1_1final.push(gdjs.Untitled_32sceneCode.GDleftObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDleftObjects1_1final, gdjs.Untitled_32sceneCode.GDleftObjects1);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects1[i].setX(430);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(false);
}
}}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDKatanaObjects2Objects = Hashtable.newFrom({"Katana": gdjs.Untitled_32sceneCode.GDKatanaObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDKatanaObjects2Objects = Hashtable.newFrom({"Katana": gdjs.Untitled_32sceneCode.GDKatanaObjects2});
gdjs.Untitled_32sceneCode.asyncCallback28052340 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(true);
}gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback28052340(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDKatanaObjects2Objects = Hashtable.newFrom({"Katana": gdjs.Untitled_32sceneCode.GDKatanaObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDWoodObjects2ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDWoodLeftObjects2ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDWoodRightObjects2Objects = Hashtable.newFrom({"Wood": gdjs.Untitled_32sceneCode.GDWoodObjects2, "WoodLeft": gdjs.Untitled_32sceneCode.GDWoodLeftObjects2, "WoodRight": gdjs.Untitled_32sceneCode.GDWoodRightObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDpointsObjects2Objects = Hashtable.newFrom({"points": gdjs.Untitled_32sceneCode.GDpointsObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDKatanaObjects3Objects = Hashtable.newFrom({"Katana": gdjs.Untitled_32sceneCode.GDKatanaObjects3});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDWoodObjects3ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDWoodLeftObjects3ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDWoodRightObjects3Objects = Hashtable.newFrom({"Wood": gdjs.Untitled_32sceneCode.GDWoodObjects3, "WoodLeft": gdjs.Untitled_32sceneCode.GDWoodLeftObjects3, "WoodRight": gdjs.Untitled_32sceneCode.GDWoodRightObjects3});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Untitled_32sceneCode.GDPlayerObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDWoodLeftObjects2Objects = Hashtable.newFrom({"WoodLeft": gdjs.Untitled_32sceneCode.GDWoodLeftObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Untitled_32sceneCode.GDPlayerObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDWoodRightObjects2Objects = Hashtable.newFrom({"WoodRight": gdjs.Untitled_32sceneCode.GDWoodRightObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Untitled_32sceneCode.GDPlayerObjects2});
gdjs.Untitled_32sceneCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("time"), gdjs.Untitled_32sceneCode.GDtimeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDtimeObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDtimeObjects2[i].getBehavior("Resizable").getWidth() < 0 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDtimeObjects2[k] = gdjs.Untitled_32sceneCode.GDtimeObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDtimeObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "difficultyTimer") > 10;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(3);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "difficultyTimer") > 20;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(2);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "difficultyTimer") > 30;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(1);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayerObjects2[i].getX() == 430 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayerObjects2[k] = gdjs.Untitled_32sceneCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(28047380);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("slice_spot"), gdjs.Untitled_32sceneCode.GDslice_9595spotObjects2);
gdjs.Untitled_32sceneCode.GDKatanaObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDKatanaObjects2Objects, (( gdjs.Untitled_32sceneCode.GDslice_9595spotObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDslice_9595spotObjects2[0].getPointX("")), (( gdjs.Untitled_32sceneCode.GDslice_9595spotObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDslice_9595spotObjects2[0].getPointY("")), "");
}{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(false);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDKatanaObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDKatanaObjects2[i].getBehavior("Resizable").setSize(8, 8);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayerObjects2[i].getX() == 700 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayerObjects2[k] = gdjs.Untitled_32sceneCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(28050468);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("slice_spot"), gdjs.Untitled_32sceneCode.GDslice_9595spotObjects2);
gdjs.Untitled_32sceneCode.GDKatanaObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDKatanaObjects2Objects, (( gdjs.Untitled_32sceneCode.GDslice_9595spotObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDslice_9595spotObjects2[0].getPointX("")), (( gdjs.Untitled_32sceneCode.GDslice_9595spotObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDslice_9595spotObjects2[0].getPointY("")), "");
}{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(false);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDKatanaObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDKatanaObjects2[i].getBehavior("Resizable").setSize(8, 8);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), false, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList3(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(28053356);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationSpeedScale(4);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("Attack");
}
}{gdjs.evtTools.sound.playMusic(runtimeScene, "Sword.MP3", false, runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber(), 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(28055300);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationSpeedScale(1);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("Idle");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Katana"), gdjs.Untitled_32sceneCode.GDKatanaObjects2);
gdjs.copyArray(runtimeScene.getObjects("Wood"), gdjs.Untitled_32sceneCode.GDWoodObjects2);
gdjs.copyArray(runtimeScene.getObjects("WoodLeft"), gdjs.Untitled_32sceneCode.GDWoodLeftObjects2);
gdjs.copyArray(runtimeScene.getObjects("WoodRight"), gdjs.Untitled_32sceneCode.GDWoodRightObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDKatanaObjects2Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDWoodObjects2ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDWoodLeftObjects2ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDWoodRightObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDKatanaObjects2 */
/* Reuse gdjs.Untitled_32sceneCode.GDWoodObjects2 */
/* Reuse gdjs.Untitled_32sceneCode.GDWoodLeftObjects2 */
/* Reuse gdjs.Untitled_32sceneCode.GDWoodRightObjects2 */
gdjs.copyArray(runtimeScene.getObjects("slice_spot"), gdjs.Untitled_32sceneCode.GDslice_9595spotObjects2);
gdjs.Untitled_32sceneCode.GDpointsObjects2.length = 0;

{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDWoodObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDWoodObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDWoodLeftObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDWoodLeftObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDWoodRightObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDWoodRightObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDKatanaObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDKatanaObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDpointsObjects2Objects, (( gdjs.Untitled_32sceneCode.GDslice_9595spotObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDslice_9595spotObjects2[0].getPointX("")), (( gdjs.Untitled_32sceneCode.GDslice_9595spotObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDslice_9595spotObjects2[0].getPointY("")), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "chopTimer");
}{runtimeScene.getScene().getVariables().getFromIndex(3).add(10);
}}

}


{

gdjs.Untitled_32sceneCode.GDKatanaObjects2.length = 0;

gdjs.Untitled_32sceneCode.GDWoodObjects2.length = 0;

gdjs.Untitled_32sceneCode.GDWoodLeftObjects2.length = 0;

gdjs.Untitled_32sceneCode.GDWoodRightObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Untitled_32sceneCode.GDKatanaObjects2_1final.length = 0;
gdjs.Untitled_32sceneCode.GDWoodObjects2_1final.length = 0;
gdjs.Untitled_32sceneCode.GDWoodLeftObjects2_1final.length = 0;
gdjs.Untitled_32sceneCode.GDWoodRightObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Katana"), gdjs.Untitled_32sceneCode.GDKatanaObjects3);
gdjs.copyArray(runtimeScene.getObjects("Wood"), gdjs.Untitled_32sceneCode.GDWoodObjects3);
gdjs.copyArray(runtimeScene.getObjects("WoodLeft"), gdjs.Untitled_32sceneCode.GDWoodLeftObjects3);
gdjs.copyArray(runtimeScene.getObjects("WoodRight"), gdjs.Untitled_32sceneCode.GDWoodRightObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDKatanaObjects3Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDWoodObjects3ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDWoodLeftObjects3ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDWoodRightObjects3Objects, true, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDKatanaObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDKatanaObjects2_1final.indexOf(gdjs.Untitled_32sceneCode.GDKatanaObjects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDKatanaObjects2_1final.push(gdjs.Untitled_32sceneCode.GDKatanaObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDWoodObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDWoodObjects2_1final.indexOf(gdjs.Untitled_32sceneCode.GDWoodObjects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDWoodObjects2_1final.push(gdjs.Untitled_32sceneCode.GDWoodObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDWoodLeftObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDWoodLeftObjects2_1final.indexOf(gdjs.Untitled_32sceneCode.GDWoodLeftObjects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDWoodLeftObjects2_1final.push(gdjs.Untitled_32sceneCode.GDWoodLeftObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDWoodRightObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDWoodRightObjects2_1final.indexOf(gdjs.Untitled_32sceneCode.GDWoodRightObjects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDWoodRightObjects2_1final.push(gdjs.Untitled_32sceneCode.GDWoodRightObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDKatanaObjects2_1final, gdjs.Untitled_32sceneCode.GDKatanaObjects2);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDWoodObjects2_1final, gdjs.Untitled_32sceneCode.GDWoodObjects2);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDWoodLeftObjects2_1final, gdjs.Untitled_32sceneCode.GDWoodLeftObjects2);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDWoodRightObjects2_1final, gdjs.Untitled_32sceneCode.GDWoodRightObjects2);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDKatanaObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDKatanaObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDKatanaObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("WoodLeft"), gdjs.Untitled_32sceneCode.GDWoodLeftObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayerObjects2Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDWoodLeftObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("WoodRight"), gdjs.Untitled_32sceneCode.GDWoodRightObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayerObjects2Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDWoodRightObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("WoodLeft"), gdjs.Untitled_32sceneCode.GDWoodLeftObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.raycastObject(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayerObjects2Objects, (( gdjs.Untitled_32sceneCode.GDWoodLeftObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDWoodLeftObjects2[0].getCenterXInScene()), (( gdjs.Untitled_32sceneCode.GDWoodLeftObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDWoodLeftObjects2[0].getCenterYInScene()), 180, 400, gdjs.VariablesContainer.badVariable, gdjs.VariablesContainer.badVariable, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDheight_95959595limitObjects2Objects = Hashtable.newFrom({"height_limit": gdjs.Untitled_32sceneCode.GDheight_9595limitObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDWoodObjects2ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDWoodLeftObjects2ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDWoodRightObjects2Objects = Hashtable.newFrom({"Wood": gdjs.Untitled_32sceneCode.GDWoodObjects2, "WoodLeft": gdjs.Untitled_32sceneCode.GDWoodLeftObjects2, "WoodRight": gdjs.Untitled_32sceneCode.GDWoodRightObjects2});
gdjs.Untitled_32sceneCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Wood"), gdjs.Untitled_32sceneCode.GDWoodObjects2);
gdjs.copyArray(runtimeScene.getObjects("WoodLeft"), gdjs.Untitled_32sceneCode.GDWoodLeftObjects2);
gdjs.copyArray(runtimeScene.getObjects("WoodRight"), gdjs.Untitled_32sceneCode.GDWoodRightObjects2);
gdjs.copyArray(runtimeScene.getObjects("height_limit"), gdjs.Untitled_32sceneCode.GDheight_9595limitObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDheight_95959595limitObjects2Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDWoodObjects2ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDWoodLeftObjects2ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDWoodRightObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, gdjs.evtTools.common.toString(gdjs.randomInRange(1, 4)), 0, 0, 0);
}{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "p", 0, 0, 0);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.Untitled_32sceneCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("points"), gdjs.Untitled_32sceneCode.GDpointsObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDpointsObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDpointsObjects2[i].addPolarForce(270, 50, 0);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("points"), gdjs.Untitled_32sceneCode.GDpointsObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDpointsObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDpointsObjects2[i].getBehavior("Tween").addObjectOpacityTween2("opacity", 0, "linear", 1, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("time"), gdjs.Untitled_32sceneCode.GDtimeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDtimeObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDtimeObjects2[i].getBehavior("Resizable").getWidth() > 0 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDtimeObjects2[k] = gdjs.Untitled_32sceneCode.GDtimeObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDtimeObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDtimeObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDtimeObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDtimeObjects2[i].getBehavior("Resizable").setWidth(((runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() - gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "chopTimer")) / 200) * 4000);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("points"), gdjs.Untitled_32sceneCode.GDpointsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDpointsObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDpointsObjects1[i].getBehavior("Opacity").getOpacity() < 20 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDpointsObjects1[k] = gdjs.Untitled_32sceneCode.GDpointsObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDpointsObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDpointsObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDpointsObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDpointsObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Untitled_32sceneCode.mapOfEmptyGDWoodObjectsEmptyGDWoodLeftObjectsEmptyGDWoodRightObjects = Hashtable.newFrom({"Wood": [], "WoodLeft": [], "WoodRight": []});
gdjs.Untitled_32sceneCode.mapOfEmptyGDpointsObjects = Hashtable.newFrom({"points": []});
gdjs.Untitled_32sceneCode.mapOfEmptyGDPlayerObjects = Hashtable.newFrom({"Player": []});
gdjs.Untitled_32sceneCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) > runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber();
if (isConditionTrue_0) {
{gdjs.evtTools.storage.writeNumberInJSONFile("score_", "score_", runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber());
}}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDrestartObjects3Objects = Hashtable.newFrom({"restart": gdjs.Untitled_32sceneCode.GDrestartObjects3});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDMenuObjects2Objects = Hashtable.newFrom({"Menu": gdjs.Untitled_32sceneCode.GDMenuObjects2});
gdjs.Untitled_32sceneCode.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("restart"), gdjs.Untitled_32sceneCode.GDrestartObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDrestartObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Untitled scene", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Untitled_32sceneCode.GDMenuObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDMenuObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


};gdjs.Untitled_32sceneCode.mapOfEmptyGDPlayerObjects = Hashtable.newFrom({"Player": []});
gdjs.Untitled_32sceneCode.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("debug"), gdjs.Untitled_32sceneCode.GDdebugObjects2);
gdjs.copyArray(runtimeScene.getObjects("scr"), gdjs.Untitled_32sceneCode.GDscrObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDdebugObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDdebugObjects2[i].getBehavior("Text").setText("number of wood: " + gdjs.evtTools.common.toString(gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfEmptyGDWoodObjectsEmptyGDWoodLeftObjectsEmptyGDWoodRightObjects)) + gdjs.evtTools.string.newLine() + "number of points: " + gdjs.evtTools.common.toString(gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfEmptyGDpointsObjects)));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDscrObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDscrObjects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(3).getAsString());
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfEmptyGDPlayerObjects) < 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gray"), gdjs.Untitled_32sceneCode.GDGrayObjects2);
{gdjs.evtTools.camera.showLayer(runtimeScene, "fail");
}{gdjs.evtTools.camera.showLayer(runtimeScene, "FailGray");
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGrayObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGrayObjects2[i].getBehavior("Opacity").setOpacity(150);
}
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList7(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "fail");
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList8(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfEmptyGDPlayerObjects) < 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(28074404);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("highscoreText"), gdjs.Untitled_32sceneCode.GDhighscoreTextObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDhighscoreTextObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDhighscoreTextObjects2[i].getBehavior("Text").setText("highscore: " + runtimeScene.getScene().getVariables().getFromIndex(4).getAsString());
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDhighscoreTextObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDhighscoreTextObjects2[i].setPosition(484,244);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readNumberFromJSONFile("score_", "score_", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(4));
}}

}


{



}


};gdjs.Untitled_32sceneCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.Untitled_32sceneCode.GDbackObjects1);
gdjs.copyArray(runtimeScene.getObjects("height_limit"), gdjs.Untitled_32sceneCode.GDheight_9595limitObjects1);
gdjs.copyArray(runtimeScene.getObjects("slice_spot"), gdjs.Untitled_32sceneCode.GDslice_9595spotObjects1);
{gdjs.playerAuthentication.displayAuthenticationBanner(runtimeScene);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "chopTimer");
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1.5, "", 0);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDslice_9595spotObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDslice_9595spotObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects1[i].setX(430);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "chopTimer");
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDheight_9595limitObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDheight_9595limitObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDbackObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDbackObjects1[i].getBehavior("Opacity").setOpacity(240);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "difficultyTimer");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "[1hour loop] Japanese traditional music (No Copyright) Koto of Zen (320 kbps).mp3", 4, false, runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber(), 1);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("restart"), gdjs.Untitled_32sceneCode.GDrestartObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDrestartObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDrestartObjects1[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDrestartObjects1[k] = gdjs.Untitled_32sceneCode.GDrestartObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDrestartObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDrestartObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDrestartObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDrestartObjects1[i].getBehavior("Effect").enableEffect("thickness", true);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDrestartObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDrestartObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.6, 3, 3, 3, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Untitled_32sceneCode.GDMenuObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDMenuObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDMenuObjects1[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDMenuObjects1[k] = gdjs.Untitled_32sceneCode.GDMenuObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDMenuObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDMenuObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDMenuObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDMenuObjects1[i].getBehavior("Effect").enableEffect("thickness", true);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDMenuObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDMenuObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.6, 3, 3, 3, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("restart"), gdjs.Untitled_32sceneCode.GDrestartObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDrestartObjects1.length;i<l;++i) {
    if ( !(gdjs.Untitled_32sceneCode.GDrestartObjects1[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDrestartObjects1[k] = gdjs.Untitled_32sceneCode.GDrestartObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDrestartObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDrestartObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDrestartObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDrestartObjects1[i].getBehavior("Effect").enableEffect("thickness", false);
}
}}

}


{


gdjs.Untitled_32sceneCode.eventsList2(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList4(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList5(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList6(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList9(runtimeScene);
}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDWoodObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDWoodObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDWoodObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDWoodObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDGroundObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGroundObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDGroundObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDGroundObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDKatanaObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDKatanaObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDKatanaObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDKatanaObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDRootObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRootObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRootObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDRootObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDWoodLeftObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDWoodLeftObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDWoodLeftObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDWoodLeftObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDWoodRightObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDWoodRightObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDWoodRightObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDWoodRightObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDbgObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDbgObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDbgObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDbgObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDheight_9595limitObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDheight_9595limitObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDheight_9595limitObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDheight_9595limitObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDdebugObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDdebugObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDdebugObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDdebugObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDslice_9595spotObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDslice_9595spotObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDslice_9595spotObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDslice_9595spotObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDpoinObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDpoinObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDpoinObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDpoinObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDpointsObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDpointsObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDpointsObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDpointsObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDtimeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDtimeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDtimeObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDtimeObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDNewTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTextObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewTextObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDbarObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDbarObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDbarObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDbarObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDscrObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDscrObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDscrObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDscrObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDFailTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDFailTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDFailTextObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDFailTextObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDrestartObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDrestartObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDrestartObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDrestartObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDhighscoreTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDhighscoreTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDhighscoreTextObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDhighscoreTextObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDbackObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDbackObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDbackObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDbackObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDHScoreObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDHScoreObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDHScoreObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDHScoreObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDMenuObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDMenuObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDMenuObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDMenuObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDGrayObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGrayObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDGrayObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDGrayObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDleftObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDleftObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDleftObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDleftObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDrightObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDrightObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDrightObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDrightObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDPlayerObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlayerObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlayerObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDPlayerObjects4.length = 0;

gdjs.Untitled_32sceneCode.eventsList10(runtimeScene);

return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
