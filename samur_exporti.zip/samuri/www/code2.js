gdjs.OptionsCode = {};
gdjs.OptionsCode.localVariables = [];
gdjs.OptionsCode.GDMenuObjects1= [];
gdjs.OptionsCode.GDMenuObjects2= [];
gdjs.OptionsCode.GDtittle2Objects1= [];
gdjs.OptionsCode.GDtittle2Objects2= [];
gdjs.OptionsCode.GDVolumeObjects1= [];
gdjs.OptionsCode.GDVolumeObjects2= [];
gdjs.OptionsCode.GDoptionsObjects1= [];
gdjs.OptionsCode.GDoptionsObjects2= [];
gdjs.OptionsCode.GDbackObjects1= [];
gdjs.OptionsCode.GDbackObjects2= [];
gdjs.OptionsCode.GDNewSpriteObjects1= [];
gdjs.OptionsCode.GDNewSpriteObjects2= [];
gdjs.OptionsCode.GDSquareWhiteSliderObjects1= [];
gdjs.OptionsCode.GDSquareWhiteSliderObjects2= [];
gdjs.OptionsCode.GDPlayerObjects1= [];
gdjs.OptionsCode.GDPlayerObjects2= [];


gdjs.OptionsCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11543204);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "Pop sound effect edited.MP3", false, runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber(), 1);
}}

}


};gdjs.OptionsCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SquareWhiteSlider"), gdjs.OptionsCode.GDSquareWhiteSliderObjects1);
{for(var i = 0, len = gdjs.OptionsCode.GDSquareWhiteSliderObjects1.length ;i < len;++i) {
    gdjs.OptionsCode.GDSquareWhiteSliderObjects1[i].SetValue(runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.OptionsCode.GDbackObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.OptionsCode.GDbackObjects1.length;i<l;++i) {
    if ( gdjs.OptionsCode.GDbackObjects1[i].getBehavior("ButtonFSM").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.OptionsCode.GDbackObjects1[k] = gdjs.OptionsCode.GDbackObjects1[i];
        ++k;
    }
}
gdjs.OptionsCode.GDbackObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SquareWhiteSlider"), gdjs.OptionsCode.GDSquareWhiteSliderObjects1);
{gdjs.evtTools.sound.playMusic(runtimeScene, "Pop sound effect edited.MP3", false, runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber(), 1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}{gdjs.evtTools.storage.writeNumberInJSONFile("VolumeValue", "Slider", (( gdjs.OptionsCode.GDSquareWhiteSliderObjects1.length === 0 ) ? 0 :gdjs.OptionsCode.GDSquareWhiteSliderObjects1[0].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.OptionsCode.GDbackObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.OptionsCode.GDbackObjects1.length;i<l;++i) {
    if ( gdjs.OptionsCode.GDbackObjects1[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.OptionsCode.GDbackObjects1[k] = gdjs.OptionsCode.GDbackObjects1[i];
        ++k;
    }
}
gdjs.OptionsCode.GDbackObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.OptionsCode.GDbackObjects1 */
{for(var i = 0, len = gdjs.OptionsCode.GDbackObjects1.length ;i < len;++i) {
    gdjs.OptionsCode.GDbackObjects1[i].getBehavior("Effect").enableEffect("thickness", true);
}
}{for(var i = 0, len = gdjs.OptionsCode.GDbackObjects1.length ;i < len;++i) {
    gdjs.OptionsCode.GDbackObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.6, 4, 4, 4, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.OptionsCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.OptionsCode.GDbackObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.OptionsCode.GDbackObjects1.length;i<l;++i) {
    if ( !(gdjs.OptionsCode.GDbackObjects1[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.OptionsCode.GDbackObjects1[k] = gdjs.OptionsCode.GDbackObjects1[i];
        ++k;
    }
}
gdjs.OptionsCode.GDbackObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.OptionsCode.GDbackObjects1 */
{for(var i = 0, len = gdjs.OptionsCode.GDbackObjects1.length ;i < len;++i) {
    gdjs.OptionsCode.GDbackObjects1[i].getBehavior("Effect").enableEffect("thickness", false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("SquareWhiteSlider"), gdjs.OptionsCode.GDSquareWhiteSliderObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber((( gdjs.OptionsCode.GDSquareWhiteSliderObjects1.length === 0 ) ? 0 :gdjs.OptionsCode.GDSquareWhiteSliderObjects1[0].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))));
}}

}


};

gdjs.OptionsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.OptionsCode.GDMenuObjects1.length = 0;
gdjs.OptionsCode.GDMenuObjects2.length = 0;
gdjs.OptionsCode.GDtittle2Objects1.length = 0;
gdjs.OptionsCode.GDtittle2Objects2.length = 0;
gdjs.OptionsCode.GDVolumeObjects1.length = 0;
gdjs.OptionsCode.GDVolumeObjects2.length = 0;
gdjs.OptionsCode.GDoptionsObjects1.length = 0;
gdjs.OptionsCode.GDoptionsObjects2.length = 0;
gdjs.OptionsCode.GDbackObjects1.length = 0;
gdjs.OptionsCode.GDbackObjects2.length = 0;
gdjs.OptionsCode.GDNewSpriteObjects1.length = 0;
gdjs.OptionsCode.GDNewSpriteObjects2.length = 0;
gdjs.OptionsCode.GDSquareWhiteSliderObjects1.length = 0;
gdjs.OptionsCode.GDSquareWhiteSliderObjects2.length = 0;
gdjs.OptionsCode.GDPlayerObjects1.length = 0;
gdjs.OptionsCode.GDPlayerObjects2.length = 0;

gdjs.OptionsCode.eventsList1(runtimeScene);

return;

}

gdjs['OptionsCode'] = gdjs.OptionsCode;
